<?php
/**
 * Plugin Name: FemCurrent Headless Bridge
 * Plugin URI: https://femcurrent.com
 * Description: Connecteur Headless officiel pour FemCurrent : gestion des en-têtes CORS, Custom Post Types (Enquêtes, Femmes leaders, Initiatives, Observatoire, Soumissions) et endpoints REST API pour formulaires.
 * Version: 1.0.1
 * Author: Équipe FemCurrent & OPAYSTECH
 * Author URI: https://femcurrent.com
 * License: GPL-2.0+
 */

if (!defined('ABSPATH')) {
    exit;
}

/* ==========================================================================
   1. GESTION DU CORS (Cross-Origin Resource Sharing)
   ========================================================================== */
add_action('init', function () {
    $allowed_origins = [
        'https://femcurrent.com',
        'https://www.femcurrent.com',
        'http://localhost:8085',
        'http://localhost:3000',
        'http://localhost:8080'
    ];

    $origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';

    if (in_array($origin, $allowed_origins) || empty($origin)) {
        header("Access-Control-Allow-Origin: " . ($origin ? $origin : '*'));
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        header("Access-Control-Allow-Credentials: true");
        header("Access-Control-Allow-Headers: Authorization, X-WP-Nonce, Content-Type, Accept, Origin, X-Requested-With");
    }

    if (isset($_SERVER['REQUEST_METHOD']) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        status_header(200);
        exit();
    }
});

/* ==========================================================================
   2. ENREGISTREMENT DES CUSTOM POST TYPES (Avec support REST API complet)
   ========================================================================== */
add_action('init', function () {

    // 1. Enquêtes & Analyses (FemCurrent Investigates)
    register_post_type('enquete', [
        'labels' => [
            'name' => 'Enquêtes',
            'singular_name' => 'Enquête',
            'add_new_item' => 'Ajouter une nouvelle enquête',
            'edit_item' => 'Modifier l’enquête'
        ],
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'rest_base' => 'enquetes',
        'menu_icon' => 'dashicons-search',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
    ]);

    // 2. Femmes à la une (Portraits & Leaders)
    register_post_type('femme_leader', [
        'labels' => [
            'name' => 'Femmes à la une',
            'singular_name' => 'Femme leader',
            'add_new_item' => 'Ajouter un portrait de femme leader',
            'edit_item' => 'Modifier le portrait'
        ],
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'rest_base' => 'femmes',
        'menu_icon' => 'dashicons-star-filled',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
    ]);

    // 3. Initiatives & Projets (FemCurrent Matendo)
    register_post_type('initiative', [
        'labels' => [
            'name' => 'Initiatives',
            'singular_name' => 'Initiative',
            'add_new_item' => 'Ajouter une initiative',
            'edit_item' => 'Modifier l’initiative'
        ],
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'rest_base' => 'initiatives',
        'menu_icon' => 'dashicons-networking',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
    ]);

    // 4. Observatoire & Ressources (FemCurrent Data)
    register_post_type('ressource', [
        'labels' => [
            'name' => 'Ressources & Études',
            'singular_name' => 'Ressource',
            'add_new_item' => 'Ajouter une ressource / étude',
            'edit_item' => 'Modifier la ressource'
        ],
        'public' => true,
        'has_archive' => true,
        'show_in_rest' => true,
        'rest_base' => 'ressources',
        'menu_icon' => 'dashicons-chart-bar',
        'supports' => ['title', 'editor', 'thumbnail', 'excerpt', 'custom-fields'],
    ]);

    // 5. Soumissions du public (Mettre en lumière & Contact - Modération)
    register_post_type('soumission', [
        'labels' => [
            'name' => 'Soumissions & Alertes',
            'singular_name' => 'Soumission',
            'add_new_item' => 'Ajouter une soumission',
            'edit_item' => 'Consulter la soumission'
        ],
        'public' => false,
        'show_ui' => true,
        'show_in_rest' => true,
        'rest_base' => 'soumissions',
        'menu_icon' => 'dashicons-email-alt',
        'supports' => ['title', 'editor', 'custom-fields'],
    ]);
});

/* ==========================================================================
   3. EXPOSITION DES CHAMPS DANS L'API REST
   ========================================================================== */
add_action('rest_api_init', function () {
    // Exposer l'image à la une en URL directe dans l'API
    register_rest_field(['post', 'enquete', 'femme_leader', 'initiative', 'ressource'], 'featured_image_url', [
        'get_callback' => function ($post) {
            $img_id = get_post_thumbnail_id($post['id']);
            return $img_id ? wp_get_attachment_image_url($img_id, 'full') : null;
        }
    ]);

    // Endpoint public pour soumission "Mettre une femme en lumière"
    register_rest_route('femcurrent/v1', '/submit-light', [
        'methods' => 'POST',
        'callback' => 'femcurrent_handle_submission',
        'permission_callback' => '__return_true',
    ]);

    // Endpoint public pour formulaire de contact
    register_rest_route('femcurrent/v1', '/contact', [
        'methods' => 'POST',
        'callback' => 'femcurrent_handle_contact',
        'permission_callback' => '__return_true',
    ]);
});

function femcurrent_handle_submission($request) {
    $params = $request->get_json_params();
    if (empty($params)) {
        $params = $request->get_body_params();
    }

    $name = sanitize_text_field(isset($params['name']) ? $params['name'] : 'Proposition anonyme');
    $type = sanitize_text_field(isset($params['type']) ? $params['type'] : 'Femme leader');
    $province = sanitize_text_field(isset($params['province']) ? $params['province'] : '');
    $role = sanitize_text_field(isset($params['role']) ? $params['role'] : '');
    $story = sanitize_textarea_field(isset($params['story']) ? $params['story'] : '');
    $contact = sanitize_text_field(isset($params['contact']) ? $params['contact'] : '');

    $content = "Type : " . $type . "\n" .
               "Nom : " . $name . "\n" .
               "Province : " . $province . "\n" .
               "Rôle/Domaine : " . $role . "\n" .
               "Contact : " . $contact . "\n\n" .
               "Description/Histoire :\n" . $story;

    $post_id = wp_insert_post([
        'post_type' => 'soumission',
        'post_title' => '[' . $type . '] ' . $name,
        'post_content' => $content,
        'post_status' => 'pending'
    ]);

    if (is_wp_error($post_id)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Erreur lors de l enregistrement'], 500);
    }

    return new WP_REST_Response(['success' => true, 'id' => $post_id, 'message' => 'Proposition enregistree avec succes.'], 200);
}

function femcurrent_handle_contact($request) {
    $params = $request->get_json_params();
    if (empty($params)) {
        $params = $request->get_body_params();
    }

    $name = sanitize_text_field(isset($params['name']) ? $params['name'] : '');
    $email = sanitize_text_field(isset($params['email']) ? $params['email'] : '');
    $subject = sanitize_text_field(isset($params['subject']) ? $params['subject'] : 'Contact general');
    $message = sanitize_textarea_field(isset($params['message']) ? $params['message'] : '');

    $content = "Nom : " . $name . "\n" .
               "Email/Tel : " . $email . "\n" .
               "Sujet : " . $subject . "\n\n" .
               "Message :\n" . $message;

    $post_id = wp_insert_post([
        'post_type' => 'soumission',
        'post_title' => '[CONTACT] ' . $subject . ' - ' . $name,
        'post_content' => $content,
        'post_status' => 'pending'
    ]);

    if (is_wp_error($post_id)) {
        return new WP_REST_Response(['success' => false, 'message' => 'Erreur'], 500);
    }

    return new WP_REST_Response(['success' => true, 'id' => $post_id, 'message' => 'Message recu.'], 200);
}
